from tkinter import *
from thongso import *
from setup_window import manhinh
import os
from nhapten import chao
import tkinter as tk

#scr = Tk( )
#app1=manhinh(scr)
#app2=chao()








#scr.mainloop( )
